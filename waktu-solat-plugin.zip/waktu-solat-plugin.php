<?php
/**
 * Plugin Name: Waktu Solat Melaka Plugin
 * Description: Plugin to show the Prayers times in Melaka city of Malaysia
 * Version: 2.0
 */

function fetch_data($atts) {
    $current_year = date('Y');
    $current_month = date('m');
    $api_url = "http://api.aladhan.com/v1/calendarByCity/{$current_year}/{$current_month}?country=malaysia&city=melaka";
    $response = wp_remote_get($api_url);
    if (is_wp_error($response)) {
        return 'Ralat mengambil waktu solat.';
    }
    set_transient('prayer_times_response', $response, 86400);
}
add_action('init', 'fetch_data');

function display_monthly_prayer_times_table($atts) {
    $prayer_times_response = get_transient('prayer_times_response');
    $data = json_decode(wp_remote_retrieve_body($prayer_times_response));

    if ($prayer_times_response && !is_wp_error($prayer_times_response) && is_array($data->data)) {
        $table_html = '<div class="prayer-times-table-container">';
        $table_html .= '<div style="overflow-x: auto;">';
        $table_html .= '<table style="width: 100%; border-collapse: collapse; margin-top: 10px;">';
        $table_html .= '<thead>';
        $table_html .= '<tr style="background-color: black; color: white;">';
        $table_html .= '<th style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">Date</th>';
        $table_html .= '<th style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">Subuh</th>';
        $table_html .= '<th style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">Zohor</th>';
        $table_html .= '<th style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">Asar</th>';
        $table_html .= '<th style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">Maghrib</th>';
        $table_html .= '<th style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">Isyak</th>';
        $table_html .= '</tr>';
        $table_html .= '</thead>';
        $table_html .= '<tbody>';

        foreach ($data->data as $day_data) {
            $formatted_date = date('M d', strtotime($day_data->date->gregorian->date));
            $row_styles = ($formatted_date == date('M d')) ? 'background-color: #D6DBDF; color: #000;' : '';
            $table_html .= '<tr style="' . $row_styles . '">';
            $table_html .= '<td style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">' . $formatted_date . '</td>';
            $table_html .= '<td style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">' . exclude_standard_string($day_data->timings->Fajr).' AM' .'</td>';
            $table_html .= '<td style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">' . exclude_standard_string($day_data->timings->Dhuhr).' PM' .'</td>';
            $table_html .= '<td style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">' . exclude_standard_string($day_data->timings->Asr).' PM' .'</td>';
            $table_html .= '<td style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">' . exclude_standard_string($day_data->timings->Maghrib).' PM'. '</td>';
            $table_html .= '<td style="padding-top: 10px; padding-bottom: 10px; border: 1px solid #ddd; text-align: center;">' . exclude_standard_string($day_data->timings->Isha).' PM' .'</td>';
            $table_html .= '</tr>';
        }
        $table_html .= '</tbody>';
        $table_html .= '</table>';
        $table_html .= '</div>';
        $table_html .= '</div>';
        return $table_html;
    } else {
        return 'Data waktu solat tidak tersedia atau tidak dalam format yang diharapkan.';
    }
}

add_shortcode('monthly-prayer-times-table', 'display_monthly_prayer_times_table');

function display_prayer_time($atts) {
    $prayer_times_data = get_transient('prayer_times_response');	
    $decoded_prayer_times_data = json_decode(wp_remote_retrieve_body($prayer_times_data));
    $prayer_name = $atts['prayer'];

    if ($decoded_prayer_times_data && is_array($decoded_prayer_times_data->data)) {
        $current_date = date('j');
        foreach ($decoded_prayer_times_data->data as $day_data) {
            if ($day_data->date->gregorian->day == $current_date) {
                $prayer_time_region = $day_data->timings->$prayer_name;
                return exclude_standard_string($prayer_time_region);
            }
        }
        return 'Prayer time not found for the current date';
    } else {
        return 'Prayer time not found';
    }
}
add_shortcode('prayer-time', 'display_prayer_time');

//Date Time Short Code
function wpb_date_today($atts, $content = null) {
	extract( shortcode_atts( array('format' => ''), $atts ) ); 
	if ($atts['format'] == '') {
		$date_time .= date(get_option('date_format'));
	}  else {
		$date_time .= date($atts['format']);
	}
	return $date_time;
}
add_shortcode('date-today','wpb_date_today');

function exclude_standard_string($string) {
    $prayer_time_parts = explode(' ', $string);
    $prayer_time = $prayer_time_parts[0]; 
    return "$prayer_time";
}
